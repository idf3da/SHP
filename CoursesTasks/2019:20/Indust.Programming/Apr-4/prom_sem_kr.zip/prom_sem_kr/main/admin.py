from django.contrib import admin

# Register your models here.
from main.models import Snippet

admin.site.register(Snippet)